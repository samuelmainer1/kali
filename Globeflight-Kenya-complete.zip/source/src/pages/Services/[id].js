// pages/services/[id].js
import React from 'react'
import { useRouter } from 'next/router'
import { Card, CardDescription, CardHeader } from "@/components/ui/card"
import Layout from "@/components/Layout"  // Assuming a layout with sidebar and hero section

export default function ServiceDetail({ service, previousService, nextService }) {
  const router = useRouter()

  // Show loading while the page is being generated
  if (router.isFallback) {
    return <div>Loading...</div>
  }

  // Check if the service data is available, otherwise show an error
  if (!service) {
    return <div className="text-center text-red-500">Service not found</div>
  }

  return (
    <Layout>
      <div className="py-10">
        {/* Service Detail Section */}
        <div className="flex flex-col space-y-4">
          <h1 className="md:text-3xl text-xl font-bold">{service.title}</h1>
          <p className="text-justify">{service.fullDesc || service.desc}</p>
        </div>

        {/* Related Services Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 my-10">
          {previousService && (
            <Card key={previousService.id} className="shadow-xl flex flex-col h-full">
              <div className="relative h-40">
                <img
                  src={previousService.img}
                  alt={previousService.title}
                  className="w-full h-full object-cover rounded-t-lg"
                />
              </div>
              <CardHeader className="py-4 flex-grow flex flex-col justify-between">
                <div>
                  <div className="flex items-center text-brandBluish">
                    {React.createElement(previousService.icon, { size: 20 })}
                    <h4 className="text-base ml-3 font-medium">{previousService.title}</h4>
                  </div>
                  <CardDescription>{previousService.desc}</CardDescription>
                </div>
                <div className="mt-4">
                  <a 
                    href={`/services/${previousService.id}`} 
                    className="bg-green-500 text-white text-xs font-medium px-4 py-2 rounded-md w-full text-center hover:bg-green-600 transition-colors inline-block"
                  >
                    Previous Service
                  </a>
                </div>
              </CardHeader>
            </Card>
          )}
          {nextService && (
            <Card key={nextService.id} className="shadow-xl flex flex-col h-full">
              <div className="relative h-40">
                <img
                  src={nextService.img}
                  alt={nextService.title}
                  className="w-full h-full object-cover rounded-t-lg"
                />
              </div>
              <CardHeader className="py-4 flex-grow flex flex-col justify-between">
                <div>
                  <div className="flex items-center text-brandBluish">
                    {React.createElement(nextService.icon, { size: 20 })}
                    <h4 className="text-base ml-3 font-medium">{nextService.title}</h4>
                  </div>
                  <CardDescription>{nextService.desc}</CardDescription>
                </div>
                <div className="mt-4">
                  <a 
                    href={`/services/${nextService.id}`} 
                    className="bg-green-500 text-white text-xs font-medium px-4 py-2 rounded-md w-full text-center hover:bg-green-600 transition-colors inline-block"
                  >
                    Next Service
                  </a>
                </div>
              </CardHeader>
            </Card>
          )}
        </div>
      </div>
    </Layout>
  )
}

export async function getStaticPaths() {
  // Optionally, fetch all slugs from API for static generation
  // For fallback: true, you can keep as is or fetch from API
  return { paths: [], fallback: true }
}

export async function getStaticProps({ params }) {
  // Fetch service from backend API
  try {
    const res = await fetch(`/admin/api/services/public/${params.id}`);
    const data = await res.json();
    if (!data.success || !data.data) {
      return { notFound: true };
    }
    // Optionally, fetch all services to get previous/next
    const allRes = await fetch('/admin/api/services/public?limit=100');
    const allData = await allRes.json();
    const services = allData.success ? allData.data.services : [];
    const index = services.findIndex(s => s.id.toString() === params.id || s.slug === params.id);
    const previousService = index > 0 ? services[index - 1] : null;
    const nextService = index < services.length - 1 ? services[index + 1] : null;
    return { props: { service: data.data, previousService, nextService } };
  } catch (err) {
    return { notFound: true };
  }
}
